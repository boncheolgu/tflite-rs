# This directory has moved

The new location is: https://github.com/tensorflow/docs/
