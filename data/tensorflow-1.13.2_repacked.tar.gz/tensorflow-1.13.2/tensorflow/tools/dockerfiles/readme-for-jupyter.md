Want more tutorials like these?

Check out tensorflow.org/tutorials!
